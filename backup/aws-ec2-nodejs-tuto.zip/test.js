const database = require('./database.json');

console.log(database.data[2].code)